# To run
    Download the files
    run these commands in the terminal:
    py -3 -m venv .venv
    .venv\Scripts\activate
    $ pip3 install flask flask-sqlalchemy gunicorn
    flask --app app run
    
    flask documentation:
    https://flask.palletsprojects.com/en/3.0.x/installation/
# FreeDev

# Short Description:
    FreeDev is a web application designed, for freelance developers who want 
    to showcase their portfolio and add to it by taking offers,and 
    Entrepreneurs who want to make their ideas come to life by looking
    for the proper developers qualified for their specific needs.

# Type of the Project:
    Web Application

# Brief Info of the Customer:
    Gokhan Bakal, Abdullah Gül University, gokhan.bakal@agu.edu.tr.
    Emails between meetings would be sufficient.

# Team Members: 
    Taha Burak Er, 2211051072, Computer Engineering.
    Yazed Aswad, 2211051078, Computer Engineering.
    Alisahib Mammadov, 2211051094, Computer Engineering.
    Serra Sayar, 2111021036, Industrial Engineering.
    Duygu Elif Kartoğlu, 2211021053, Industrial Engineering.

